import java.util.Scanner;
import java.util.concurrent.locks.ReentrantLock;

class Lab9Helper extends Thread {
	private String str1;
	private String str2;
	ReentrantLock lock;

	public Lab9Helper(String str1, String str2, ReentrantLock lock) {
		super();
		this.str1 = str1;
		this.str2 = str2;
		this.lock = lock;
	};

	@Override
	public void run() {
		System.out.println("Run of  " + Thread.currentThread().getName() + " Started");

		try {
			lock.lock();
			System.out.println(Thread.currentThread().getName() + " has taken the lock on " + str1
					+ " and now waiting for next string");
			Thread.sleep(5000);
			System.out.println(Thread.currentThread().getName() + " has taken the lock on " + str1 + " " + str2);
			Thread.sleep(5000);
			System.out.println("Queuelenght" + lock.getQueueLength());
			System.out.println(Thread.currentThread().getName() + " has taken the lock on " + str1 + " " + str2);
			Thread.sleep(5000);
			lock.unlock();
		} catch (Exception e) {
		}

		finally {

		}

	}
}

public class Lab9 {
	public static void main(String[] args) throws Exception {
		System.out.println("Enter a number to continue..");
		Scanner scanner = new Scanner(System.in);
		scanner.nextInt();
		ReentrantLock lock = new ReentrantLock();
		String str1 = "str1";
		String str2 = "str2";
		Lab9Helper t1 = new Lab9Helper(str1, str2, lock);
		Lab9Helper t2 = new Lab9Helper(str2, str1, lock);
		t1.start();
		t2.start();

	}
}