import java.util.Scanner;
import java.util.stream.Stream;

public class Lab2 {
	static boolean flag = true;
    public static void main(String[] args) throws InterruptedException {
    	
    	System.out.println("Enter  a number to continue");
		Scanner scanner = new Scanner(System.in);
		scanner.nextInt();
	
		
        ThreadGroup carsGroup = new ThreadGroup("cars");
        ThreadGroup obstaclesGroup = new ThreadGroup("obstacles");
    
        Thread c1 = new Thread(carsGroup, new Car());
        c1.setName("c1");
        
        Thread c2 = new Thread(carsGroup, new Car());
        c2.setName("c2");
        
        Thread c3 = new Thread(carsGroup, new Car());
        c3.setName("c3");
        
        Thread o1 = new Thread(obstaclesGroup, new Obstacle());
        o1.setName("o1");
        
        Thread o2 = new Thread(obstaclesGroup, new Obstacle());
        o2.setName("o2");
        
        Thread o3 = new Thread(obstaclesGroup, new Obstacle());
        o3.setName("o3");
        

        c1.start();
        c2.start();
        c3.start();
        
        o1.start();
        o2.start();
        o3.start();
        
        System.out.println("Current Active Count for CarsGroup=" + carsGroup.activeCount());
        carsGroup.list();
        
        System.out.println("\n\nTake Thread Dump........................");
        Thread[] arr = new Thread[5];
    	carsGroup.enumerate(arr);
    	Stream.of(arr).forEach(System.out::println);
        Thread.sleep(5000);
        flag = false;
        System.out.println("\n\nTake Thread Dump........................");
        	
        
    }
    
}
class Car implements Runnable{
    @Override
    public void run() {
        for(int i=0;i<20 && Lab2.flag == true;i++) {
               	System.out.println("Car is running by thread: "+Thread.currentThread().getName());
            try {
                Thread.sleep((int)(Math.random()*1000));
            } catch (InterruptedException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
    } 
}
class Obstacle implements Runnable{
    @Override
    public void run() {
        for(int i=0;i<10;i++) {
            System.out.println("Obstacle is running by thread: "+Thread.currentThread().getName());
            try {
            	Thread.sleep((int)(Math.random()*1000));
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        
    }
    
}
