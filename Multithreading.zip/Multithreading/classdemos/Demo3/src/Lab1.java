import java.util.Scanner;

class Lab1Support implements Runnable {
	
	@Override
	public void run() {
		for (int i = 0; i < 9999900; i++) {
			System.out.print(Thread.currentThread().getName());
			if (( i %80 )==0)
				System.out.println();
		}
	}
}

public class Lab1 {

	public static void main(String[] args) {
		System.out.println("Enter  a number to continue");
		Scanner scanner = new Scanner(System.in);
		scanner.nextInt();
		Thread thread1 = new Thread(new Lab1Support());
		thread1.setName("x");
		thread1.setPriority(Thread.MAX_PRIORITY);
		Thread thread2 = new Thread(new Lab1Support());
		thread2.setName("o");
		Thread thread3 = new Thread(new Lab1Support());
		thread3.setName("b");
		thread1.start();
		thread2.start();
		thread3.start();
		System.out.println(" \n\nend of main thread...");
	}

}
