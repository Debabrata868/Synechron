import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

class Lab1Runnable implements Runnable {
	@Override
	public void run() {
		System.out.println("in run of Lab1Runnable, Thread Name = " + Thread.currentThread().getName());
	}
}

class Lab1Callable implements Callable<String> {

	private String name;

	public Lab1Callable(String name) {
		this.name = name;
	}

	@Override
	public String call() throws Exception {
		System.out.println("in call of Lab1Callable, Thread Name = " + Thread.currentThread().getName());
		
		Thread.sleep(5000);
		return "hello, " + name;
	}

}

public class Lab1 {
	public static void main(String[] args) throws InterruptedException, ExecutionException {
		System.out.println("Main Method, Thread Name = " + Thread.currentThread().getName());

		ExecutorService service = Executors.newSingleThreadExecutor();
		Runnable runable = new Lab1Runnable();
		service.execute(runable);
		service.execute(runable);
		service.execute(runable);
		
		Future<String> futureString  = service.submit(new Lab1Callable("fands"));
		System.out.println("after future string...");
		System.out.println(" after processing is done , return = " + futureString.get());
		service.shutdown();
	}
}
