import java.util.Scanner;

public class Lab4 {

	public static void main(String[] args) {

		System.out.println("Enter  a number to continue");
		Scanner scanner = new Scanner(System.in);
		scanner.nextInt();
		
		Runnable runnable = () ->{	for (int i = 0; i< 50000;i++){
			System.out.println("b");
		}};
		
		Thread thread1 = new Thread(runnable);
		thread1.start();
	}

}
