import java.util.Scanner;

class Lab3Support implements Runnable
{
@Override
public void run() {
	for (int i = 0; i< 50000;i++){
		System.out.println("a");
	}
}	
}
public class Lab3 {

	public static void main(String[] args) {
		System.out.println("Enter  a number to continue");
		Scanner scanner = new Scanner(System.in);
		scanner.nextInt();
		Thread thread1 = new Thread(new Lab3Support());
		thread1.start();
	}

}
