import java.util.Scanner;

class Lab2Support extends Thread
{
@Override
public void run() {
	for (int i = 0; i< 5000;i++){
		System.out.println("a");
	}
}	
}
public class Lab2 {

	public static void main(String[] args) {
		System.out.println("Enter  a number to continue");
		Scanner scanner = new Scanner(System.in);
		scanner.nextInt();
		Lab2Support thread1 = new Lab2Support();
		thread1.start();
	}

}
