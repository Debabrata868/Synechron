import java.util.Scanner;

public class Lab1 {

	public static void main(String[] args) throws Exception{
	
		System.out.println("Enter  a number to continue");
		Scanner scanner = new Scanner(System.in);
		scanner.nextInt();
		for (int i = 0; i< 50000;i++){
			System.out.println("a");
		}
	}

}
