import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.RecursiveTask;
import java.util.function.Predicate;
import java.util.stream.Collectors;

class MyRecursiveTask extends RecursiveTask<List<String>> {
	private List<String> inputlist;
	private Predicate<String> pred;

	public MyRecursiveTask(List<String> inputlist, Predicate<String> pred) {
		this.inputlist = inputlist;
		this.pred = pred;
	}

	private List<MyRecursiveTask> createList(){
		List<MyRecursiveTask> list1 = new ArrayList<>();
		// option1 -  hardcoded -> option 2 - recursive
		list1.add(	new MyRecursiveTask(inputlist.subList(0, inputlist.size() / 2), pred));
		list1.add(new MyRecursiveTask(inputlist.subList(inputlist.size() / 2, inputlist.size()), pred));
		return list1;
	}
	
	@Override
	protected List<String> compute() {
		if (inputlist.size() > 100) // huge task, break it 
		{
			List<MyRecursiveTask> tasklist = createList();
			for (int i = 0; i < tasklist.size(); i++) {
				tasklist.get(i).fork();
			}
			List<String> outputlist = new ArrayList<>();
			for (int i = 0; i < tasklist.size(); i++) {
				outputlist.addAll(tasklist.get(i).join());
			}
			return outputlist;
			
		} else // very small task, do it
		{
			System.out.println("Filtering in Thread " + Thread.currentThread().getName());
			List<String> outputlist = inputlist.stream().filter(pred).collect(Collectors.toList());
			return outputlist;
		}
	}

}

public class Lab2 {
	public static void main(String[] args) {
		System.out.println("Enter  a number to continue");
		Scanner scanner = new Scanner(System.in);
		scanner.nextInt();
		List<String> list = new ArrayList<String>();
		for (int i = 0; i < 2000; i++) {
			list.add("str" + i);
		}
		Predicate<String> p = a -> a.length() > 5;

		ForkJoinPool pool = new ForkJoinPool();
		MyRecursiveTask task = new MyRecursiveTask(list, p);
		// No return - pool.execute(task);
		List<String> ret = pool.invoke(task);
		System.out.println(ret);
	}
}
