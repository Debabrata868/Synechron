import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Lab1 {
public static void main(String[] args) {
	System.out.println("Enter  a number to continue");
	Scanner scanner = new Scanner(System.in);
	scanner.nextInt();

	List<String> list  = new ArrayList<String>();
	for(int i = 0; i< 50000;i++){
		list.add("str"+i);
	}
//	list.stream().filter((str)->str.length()>7).forEach(System.out::println);
	list.parallelStream().filter((str)->str.length()>7).forEach(System.out::println);
}
}
