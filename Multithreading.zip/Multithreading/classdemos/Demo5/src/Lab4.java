import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

class Lab4Support implements Runnable {
	private Lock lock;
	private List<String> list;

	public Lab4Support(List<String> list, Lock lock) {
		this.list = list;
		this.lock = lock;
	}

	@Override
	public void run() {

		for (int i = 0; i < 100; i++) {
				lock.lock();
				System.out.println("After lock of " + Thread.currentThread().getName());
				try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				list.add(Thread.currentThread().getName() + "" + i);
				lock.unlock();
		}
		}
	}

public class Lab4 {
	final static Lock lock = new ReentrantLock(true); 
	public static void main(String[] args) {
		System.out.println("Enter  a number to continue");
		Scanner scanner = new Scanner(System.in);
		scanner.nextInt();
		List<String> list = new ArrayList<>();
		Thread t1 = new Thread(new Lab4Support(list, lock));
		t1.setName("t1");
		Thread t2 = new Thread(new Lab4Support(list,lock));
		t2.setName("t2");
		Thread t3 = new Thread(new Lab4Support(list,lock));
		t3.setName("t3");
		t1.start();
		t2.start();
		t3.start();
		try {
			t1.join();
			t2.join();
			t3.join();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("List Size =" + list.size());
	}
}
