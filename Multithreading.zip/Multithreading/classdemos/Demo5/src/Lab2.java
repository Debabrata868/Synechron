import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

class Lab2Support implements Runnable {
		private List<String> list;
		private CountDownLatch latch;
		public Lab2Support(List<String> list, CountDownLatch latch) {
			this.list = list;
			this.latch = latch;
		}
		@Override
		public void run() {
			for(int i = 0 ; i < 100;i++){
				list.add(Thread.currentThread().getName()+""+i);
			}
			latch.countDown();
			
		}
	}


public class Lab2 {
   final static CountDownLatch latch = new CountDownLatch(3);
    public static void main(String[] args) throws InterruptedException {
        List<String> list = Collections.synchronizedList(new ArrayList<>());
    
        System.out.println("Starting with Countdown latch 3");
        ExecutorService service = Executors.newCachedThreadPool();
        service.submit(new Lab2Support(list, latch));
        service.submit(new Lab2Support(list, latch));
        System.out.println("Current Count = " + latch.getCount());
        service.submit(new Lab2Support(list, latch));
        System.out.println("Current Count = " + latch.getCount());
        latch.await();
        System.out.println("List Size =" + list.size());
        service.shutdown();
    }
}