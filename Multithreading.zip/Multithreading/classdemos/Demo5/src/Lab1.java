import java.util.Scanner;
import java.util.concurrent.CountDownLatch;

class Lab1Support implements Runnable {
//	private static boolean flag=true;
	private CountDownLatch latch;
	private String name;

	public Lab1Support(String name, CountDownLatch latch) {
		this.name = name;
		this.latch = latch;
	}

	@Override
	public void run() {
		for (int i = 0; i < 10 /* && flag == true */; i++) {
			System.out.println("Thread " + name + ", current i = " + i);
			try {
				Thread.sleep((int) (Math.random() * 1000));
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		System.out.println("***********************Thread " + name + " completed....");
		latch.countDown();
		/*if (flag == true){
			System.out.println("Thread " + name + " completed....");
			flag = false;
		}*/
		
	}
}

public class Lab1 {

	public static void main(String[] args) throws Exception {
/*		System.out.println("Enter  a number to continue");
		Scanner scanner = new Scanner(System.in);
		scanner.nextInt();
		
*/		
		CountDownLatch latch = new CountDownLatch(3);
		Thread thread1 = new Thread(new Lab1Support("Place1", latch));
		Thread thread2 = new Thread(new Lab1Support("Place2",latch));
		Thread thread3 = new Thread(new Lab1Support("Place3",latch));
		thread1.start();
		System.out.println("\tCurrent Count = " + latch.getCount());
		thread2.start();
		thread3.start();
		System.out.println("\tCurrent Count = " + latch.getCount());
		System.out.println("almost end of main , just before await....");
		latch.await();
		System.out.println("after await");
		
	}

}
