import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

class Lab2Support implements Runnable {
	private List<String> list;

	public Lab2Support(List<String> list) {
		this.list = list;
	}

	@Override
	public void run() {
		for(int i = 0 ; i < 100;i++){
			list.add(Thread.currentThread().getName()+""+i);
		}
	}
}

public class Lab2 {

	public static void main(String[] args) {
//		List<String> list = new ArrayList<>();
		List<String> list = Collections.synchronizedList(new ArrayList<>());
		Thread t1 = new Thread(new Lab2Support(list));
		t1.setName("t1");
		Thread t2 = new Thread(new Lab2Support(list));
		t2.setName("t2");
		Thread t3 = new Thread(new Lab2Support(list));
		t3.setName("t3");
		t1.start();
		t2.start();
		t3.start();
		try {
			t1.join();
			t2.join();
			t3.join();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("List Size =" + list.size());
	}
}
