
1. Create a Spring Boot Starter Project 
2. Add Lombok,Web,Data JPA and mysql
3. Create a Entity Class Invoice
4. Create a Repository Invoice Repository
5. Create a Service InvoiceService
6. Create a Controller InvoiceController
7. AutoWire Repository to service and call the methods
8. AutoWire Service to Controller and call the methods
9. Annotate the Controller methods matching to HTTP Verb
10. Update the application.properties with jdbc and jpa related properties
11. Test the application using postman

