Task - 1

1. Download Lombok.jar from https://projectlombok.org/download
2. Copy the downloaded jar to spring Suite Context Path 
	E:\training\training_softwares\sts-4.1.2.RELEASE
3. Run the jar file  java -jar lombok.jar
4. Paste Spring Tool Suite Path 
     E:\training\training_softwares\sts-4.1.2.RELEASE
5. Once Installation is done , quite installer

6. Start the Spring Toolsuite


===================================================

1. Create a Spring Boot Starter Project 
2. Enter the Project Name and Add the Dependency Web and lombok 
3. Create a Java Class Product with few dependency
