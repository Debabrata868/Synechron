package demo;

import org.springframework.context.annotation.Lazy;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component(value="hsql")
@Scope(value="singleton")
@Lazy
class HSQLConnection implements Connection{
	public HSQLConnection(){
		System.out.println("HSQLConnection constructor invoked ..");
	}
	public void open(){
		
		System.out.println("HSQLConnection open method invoked");
	}
	public void close(){
		System.out.println("HSQLConnection close method invoked");
	}
}
