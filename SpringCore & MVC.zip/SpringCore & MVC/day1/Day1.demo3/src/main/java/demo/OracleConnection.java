package demo;

import org.springframework.context.annotation.Lazy;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component(value="oracle")
@Scope(value="singleton")
@Lazy
class OracleConnection implements Connection{
	public OracleConnection(){
		System.out.println("OracleConnection constructor invoked ..");
	}
	public void open(){
		
		System.out.println("OracleConnection open method invoked");
	}
	public void close(){
		System.out.println("OracleConnection close method invoked");
	}
}
