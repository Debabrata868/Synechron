package demo;

import javax.annotation.PostConstruct;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

@Component
public class DeptDAO {
	@Autowired
	private DataSource ds;
	private JdbcTemplate template;
	@PostConstruct
	public void init(){
		template=new JdbcTemplate(ds);
	}
	public void insert(Dept d){
		 
		
		String sql = "insert into dept11 values (" + d.getDeptno() + ",'" + d.getDname() + "','"+ d.getLoc() + "')";
		System.out.println("in insert " + sql);
		template.execute(sql);
	}
}
