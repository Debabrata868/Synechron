package demo;

import javax.sql.DataSource;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

@Configuration
@ComponentScan(basePackages="demo")
public class Demo5Application {
	@Bean
	public DataSource getds(){
		return new DriverManagerDataSource("jdbc:hsqldb:hsql://localhost/", "SA","");
		
	}
	
	public static void main(String[] args) {
		ApplicationContext ctx = new AnnotationConfigApplicationContext(Demo5Application.class);
		DeptDAO dao = ctx.getBean(DeptDAO.class);
		Dept d = new Dept();
		d.setDeptno(10) ; d.setDname("HR"); d.setLoc("Blr");
		dao.insert(d);
	}

}
