package demo;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
@Configuration
@ComponentScan(basePackages="demo")
public class Demo4ClientApplication {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ApplicationContext ctx = new AnnotationConfigApplicationContext(Demo4ClientApplication.class);
		DeptDAO dao = ctx.getBean("deptdao",DeptDAO.class);

/*		Connection oracle = ctx.getBean("oracle",OracleConnection.class);
		dao.setCon(oracle);
*/	
		dao.insert();
	}

}
