package demo;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Component(value="deptdao")
class DeptDAO 
	{
		@Autowired()
		@Qualifier(value="hsql")
		private Connection con;
	
		public DeptDAO() {
			System.out.println("DeptDAO Constructor, current value of  con  " + con);
		}

		@PostConstruct
		public void mymethod(){
			System.out.println("MyMethod - current value of con = " + con);
		}

		public void insert(){
			con.open();
			System.out.println("in insert...");
			con.close();
		}

		public Connection getCon() {
			return con;
		}

		public void setCon(Connection con) {
			this.con = con;
		}
	
	}