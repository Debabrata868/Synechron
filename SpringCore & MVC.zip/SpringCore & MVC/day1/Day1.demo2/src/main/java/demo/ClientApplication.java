package demo;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Lazy;
import org.springframework.context.annotation.Scope;
import org.springframework.context.support.ClassPathXmlApplicationContext;
@Configuration
public class ClientApplication {
@Bean
@Scope(value="prototype")
	public Connection oracle(){
		return new OracleConnection();
	}
	@Bean
	@Scope(value="prototype")
	
	public Connection hsql(){
		return new HSQLConnection();
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		BeanFactory factory = new ClassPathXmlApplicationContext("demo1.xml");
		ApplicationContext context = new AnnotationConfigApplicationContext(ClientApplication.class);
    	Connection con = (Connection) context.getBean("oracle");
		con.open();
		con.close();
		con = (Connection) context.getBean("oracle");
		con.open();
		con.close();
	}

}
