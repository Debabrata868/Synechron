package demo;
class OracleConnection implements Connection{
	public OracleConnection(){
		System.out.println("OracleConnection constructor invoked ..");
	}
	public void open(){
		
		System.out.println("OracleConnection open method invoked");
	}
	public void close(){
		System.out.println("OracleConnection close method invoked");
	}
}
