package demo;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class ClientApplication {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		BeanFactory factory = new ClassPathXmlApplicationContext("demo1.xml");
    	Connection con = (Connection) factory.getBean("oracle");
		con.open();
		con.close();
		con = (Connection) factory.getBean("oracle");
		con.open();
		con.close();
	}

}
