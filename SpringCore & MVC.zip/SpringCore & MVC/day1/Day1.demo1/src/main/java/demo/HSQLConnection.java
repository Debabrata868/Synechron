package demo;
class HSQLConnection implements Connection{
	public HSQLConnection(){
		System.out.println("HSQLConnection constructor invoked ..");
	}
	public void open(){
		
		System.out.println("HSQLConnection open method invoked");
	}
	public void close(){
		System.out.println("HSQLConnection close method invoked");
	}
}
