package demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class Demo13Application {

  public static void main(String[] args) {
    SpringApplication.run(Demo13Application.class, args);
  }
  @Bean
  public String demo1(DeptRepository repository){
		for (int i = 10; i < 100; i += 10) {
			Dept d1 = new Dept();
			d1.setDeptno(i);
			d1.setDname("DNAMEof"+i);
			if ((i%20)==0)
				d1.setLoc("Blr");
			else
				d1.setLoc("Pnq");
			repository.save(d1);
		}
		repository.deleteById(30); //dao.delete(30);
		Dept d = new Dept();
		d.setDeptno(10);
		d.setDname("TRAINING");
		d.setLoc("Hyderabad");
		repository.save(d);
		
		repository.findAll().forEach(System.out::println);
		
	  return "ss";
  }
  
  @Bean
  public String demo(CustomerRepository repository) {
    
      // save a few customers
      repository.save(new Customer("Jack", "Bauer"));
      repository.save(new Customer("Chloe", "O'Brian"));
      repository.save(new Customer("Kim", "Bauer"));
      repository.save(new Customer("David", "Palmer"));
      repository.save(new Customer("Michelle", "Dessler"));

      for (Customer customer : repository.findAll()) {
    	  	System.out.println(customer.toString());
      }
      
      // fetch an individual customer by ID
      Customer customer = repository.findById(1L);
      System.out.println("Customer found with findById(1L):");
      System.out.println("--------------------------------");
      System.out.println(customer.toString());
      System.out.println("");

      // fetch customers by last name
      System.out.println("Customer found with findByLastName('Bauer'):");
      System.out.println("--------------------------------------------");
      repository.findByLastName("Bauer").forEach(bauer -> {
        System.out.println(bauer.toString());
      });
      // for (Customer bauer : repository.findByLastName("Bauer")) {
      //  System.out.println(bauer.toString());
      // }
      System.out.println("");
      return " aa";
  };
  

}

