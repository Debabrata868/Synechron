package custom;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;


@Controller
@RequestMapping(value="/depts")
public class DeptController {

	@Autowired
	private DeptDAO dao;
//	private List<Dept> list =new ArrayList();
	
	
	@GetMapping
	@ResponseBody
	public String list(){
		
		String str = "<Table bgcolor='cyan' border='1'>";
		str +="<tr><td>Deptno</td><td>Dname</td><td>Loc</td></tr>";
		for (Dept dept : dao.list()) {
			str += "<tr><td>"+ dept.getDeptno() + "</td><td>"+ dept.getDname()  +"</td><td>"+ dept.getLoc()+"</td></tr>";
		}
		str+= "</table>";
		System.out.println(str);
		return str;
	}
	
	@GetMapping(value="/bydeptno")
	public String delete(@RequestParam(name="deptno") int deptno){
		System.out.println("DeptController delete invoked with " + deptno);
		dao.delete(deptno);
		return "/index.html";
		}
	@PostMapping(value="update")
	public String update(Dept dept1){
			System.out.println("DeptController  updating..");
			dao.update(dept1);
			return "/index.html";
	}

	@PostMapping
	public String insert(Dept d){
		System.out.println("DeptController insert ..." + d);
		dao.insert(d);
		return "/index.html";
	}
	
}
