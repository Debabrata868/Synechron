package custom;

import java.util.Properties;

import javax.sql.DataSource;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.orm.hibernate5.HibernateTransactionManager;
import org.springframework.orm.hibernate5.LocalSessionFactoryBean;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

@Configuration
@EnableTransactionManagement
public class MyConfig {
	private DataSource getds(){
		DriverManagerDataSource ds = new DriverManagerDataSource("jdbc:hsqldb:hsql://localhost/", "SA","");
		ds.setDriverClassName("org.hsqldb.jdbc.JDBCDriver");
		return ds;	
	}
	 private final Properties hibernateProperties() {
	        Properties hibernateProperties = new Properties();
	        hibernateProperties.setProperty("hibernate.hbm2ddl.auto", "create");
	        hibernateProperties.setProperty( "hibernate.dialect", "org.hibernate.dialect.HSQLDialect");
	        hibernateProperties.setProperty( "hibernate.show_sql", "true");
	        return hibernateProperties;
	    }
	
	@Bean 
	public LocalSessionFactoryBean sf(){
		LocalSessionFactoryBean  localsfbean = new LocalSessionFactoryBean();
		localsfbean.setDataSource(getds());
		localsfbean.setAnnotatedClasses(custom.Dept.class);
		localsfbean.setHibernateProperties(hibernateProperties());
		return localsfbean;
	}	
	
	@Bean
	public PlatformTransactionManager tx() {
		HibernateTransactionManager tm = new HibernateTransactionManager();
		LocalSessionFactoryBean sf = sf();
		tm.setSessionFactory(sf.getObject());
		return tm;
	}
	
	
}
