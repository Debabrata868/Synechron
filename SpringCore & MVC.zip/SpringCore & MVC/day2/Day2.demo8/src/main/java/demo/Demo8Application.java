package demo;

import java.util.Properties;

import javax.sql.DataSource;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.orm.hibernate5.HibernateTransactionManager;
import org.springframework.orm.hibernate5.LocalSessionFactoryBean;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

@Configuration
@ComponentScan(basePackages="demo")
@EnableTransactionManagement
public class Demo8Application {
	
	@Autowired
	private SessionFactory sf;
	private DataSource getds(){
		return new DriverManagerDataSource("jdbc:hsqldb:hsql://localhost/", "SA","");	
	}
	 private final Properties hibernateProperties() {
	        Properties hibernateProperties = new Properties();
	        hibernateProperties.setProperty("hibernate.hbm2ddl.auto", "create");
	        hibernateProperties.setProperty( "hibernate.dialect", "org.hibernate.dialect.HSQLDialect");
	        hibernateProperties.setProperty( "hibernate.show_sql", "true");
	        return hibernateProperties;
	    }
	
	@Bean 
	public LocalSessionFactoryBean sf(){
		LocalSessionFactoryBean  localsfbean = new LocalSessionFactoryBean();
		localsfbean.setDataSource(getds());
	//	localsfbean.setAnnotatedPackages("demo");
		localsfbean.setAnnotatedClasses(Dept.class,Emp.class);
		//localsfbean.setAnnotatedClasses(demo.Dept.class);
		//localsfbean.setAnnotatedClasses(demo.Emp.class);
		
		localsfbean.setHibernateProperties(hibernateProperties());
		return localsfbean;
	}	
	@Bean
	public  HibernateTemplate template(){
		return new HibernateTemplate(sf);
	}
	
	
	@Bean
	public PlatformTransactionManager tx() {
		HibernateTransactionManager tm = new HibernateTransactionManager();
		LocalSessionFactoryBean sf = sf();
		
		tm.setSessionFactory(sf.getObject());
		return tm;
	}
	
	public static void main(String[] args) {
			ApplicationContext ctx = new AnnotationConfigApplicationContext(Demo8Application.class);
			Dept dept = new Dept ();
			dept.setDeptno(101);
			dept.setDname("Fands");
			dept.setLoc("Pnq");
			Emp[] arr = new Emp[2];
			for (int i = 1; i < 3; i++) {
				Emp e1 = new Emp();
				e1.setEmpno(i);
				e1.setEname("Nameof"+i);
				e1.setSalary(i*1000);
				arr[i-1] = e1; 
			}
			DeptEmp de = ctx.getBean(DeptEmp.class);
			de.insert(dept, arr);
	}

}
