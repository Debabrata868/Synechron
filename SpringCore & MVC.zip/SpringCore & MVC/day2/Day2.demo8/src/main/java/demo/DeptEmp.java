package demo;

import java.util.List;

import javax.annotation.PostConstruct;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;


@Service(value="deptemp")
@Transactional(propagation=Propagation.REQUIRED)
public class DeptEmp {
	@Autowired
	private EmpDAO empdao;
	@Autowired
	private DeptDAO deptdao;
	
	public void insert(Dept d, Emp[] emparr)
			{
				deptdao.insert(d);
				for (int i = 0; i < emparr.length; i++) {
					empdao.insert(emparr[i]);
				}
			}
}

