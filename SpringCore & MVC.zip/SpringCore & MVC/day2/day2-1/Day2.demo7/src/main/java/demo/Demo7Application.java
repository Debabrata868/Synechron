package demo;

import org.springframework.aop.framework.ProxyFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan(basePackages="demo")
public class Demo7Application {

	@Bean(value="mydemo")
	public MyDemo getbean(){
		// create proxy
		ProxyFactory proxy = new ProxyFactory(new MyDemo());
		proxy.addAdvice(new MyLogger());
		proxy.addAdvice(new MyAudit());
		return (MyDemo)proxy.getProxy();
		//return new DeptDAO();
	}
	
	public static void main(String[] args) {
			ApplicationContext ctx = new AnnotationConfigApplicationContext(Demo7Application.class);
			MyDemo demo = ctx.getBean("mydemo",MyDemo.class);
			demo.helloWorld("he");
			
			demo.add(200,300);
	}

}
