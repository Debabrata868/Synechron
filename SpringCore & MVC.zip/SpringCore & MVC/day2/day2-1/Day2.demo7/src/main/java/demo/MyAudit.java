package demo;

import java.lang.reflect.Method;

import org.springframework.aop.MethodBeforeAdvice;
import org.springframework.aop.ThrowsAdvice;

public class MyAudit implements  MethodBeforeAdvice, ThrowsAdvice 
{

	public void before(Method arg0, Object[] arg1, Object arg2) throws Throwable {
System.out.println(".... before of MyAudit");
		
	}
	public void afterThrowing(Method method, Object[] args, Object target, Exception ex)
	{
		System.out.println(" after throwing ...." + method.getName());
	}
	
}
