package demo;

import java.lang.reflect.Method;
import java.util.Arrays;

import org.springframework.aop.AfterReturningAdvice;
import org.springframework.aop.MethodBeforeAdvice;


//advice
// joinpoint - method
// pointcut -> all methods
public class MyLogger implements MethodBeforeAdvice, AfterReturningAdvice
{
	public void before(Method method, Object[] args, Object target) throws Throwable {
		// TODO Auto-generated method stub
		System.out.println("..............Before method ... " + method.getName() + ", params = " + Arrays.toString(args) );
	}

	public void afterReturning(Object returnValue, Method method, Object[] args, Object target) throws Throwable {
		System.out.println("............after returning ....." + method.getName() + ", return value = " + returnValue);
		
	}

	
}
