package demo;

import org.springframework.stereotype.Component;
// target
@Component()
public class MyDemo {
	public String helloWorld(String name){
		System.out.println("helloworld of MyDemo invoked with " + name);
		if (name.length() < 3)
			throw new RuntimeException("name length less than 3");
		return "hello, "+ name;
	}
	public int add(int i, int j){
		System.out.println("add of MyDemo invoked with " + i + ", "+ j);
		return (i+j);
		
	}
}
