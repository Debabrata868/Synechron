package demo;

import java.util.List;

import javax.annotation.PostConstruct;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

@Component(value="deptdao")
@Transactional(propagation=Propagation.REQUIRED)
public class DeptDAO {

	@Autowired
	private SessionFactory sessionfactory;
	private HibernateTemplate template;
	
	@PostConstruct
	public void init(){
		template = new HibernateTemplate(sessionfactory);
	}
	
	public void insert(Dept d){
		System.out.println("insert of DeptDAO invoked with "  + d);
		template.save(d);
	}
	
	public List<Dept> list(){
		System.out.println("DeptDAO list");
		return template.loadAll(Dept.class);
	}
	
	public void delete(int deptno){
		Dept d = template.get(Dept.class,deptno);
		template.delete(d);
	}
	
	public void update(Dept dept){
		template.update(dept);
	}	
}
