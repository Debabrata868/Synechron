package demo;

import java.util.Properties;

import javax.sql.DataSource;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.orm.hibernate5.HibernateTransactionManager;
import org.springframework.orm.hibernate5.LocalSessionFactoryBean;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

@Configuration
@ComponentScan(basePackages="demo")
@EnableTransactionManagement
public class Demo6Application {
	private DataSource getds(){
		return new DriverManagerDataSource("jdbc:hsqldb:hsql://localhost/", "SA","");	
	}
	 private final Properties hibernateProperties() {
	        Properties hibernateProperties = new Properties();
	        hibernateProperties.setProperty("hibernate.hbm2ddl.auto", "create");
	        hibernateProperties.setProperty( "hibernate.dialect", "org.hibernate.dialect.HSQLDialect");
	        hibernateProperties.setProperty( "hibernate.show_sql", "true");
	        return hibernateProperties;
	    }
	
	@Bean 
	public LocalSessionFactoryBean sf(){
		LocalSessionFactoryBean  localsfbean = new LocalSessionFactoryBean();
		localsfbean.setDataSource(getds());
		localsfbean.setAnnotatedClasses(demo.Dept.class);
		localsfbean.setHibernateProperties(hibernateProperties());
		return localsfbean;
	}	
	
	@Bean
	public PlatformTransactionManager tx() {
		HibernateTransactionManager tm = new HibernateTransactionManager();
		LocalSessionFactoryBean sf = sf();
		
		tm.setSessionFactory(sf.getObject());
		return tm;
	}
	
	public static void main(String[] args) {
			ApplicationContext ctx = new AnnotationConfigApplicationContext(Demo6Application.class);
			DeptDAO dao = ctx.getBean("deptdao" ,DeptDAO.class);
			
			for (int i = 10; i < 100; i += 10) {
				Dept d1 = new Dept();
				d1.setDeptno(i);
				d1.setDname("DNAMEof"+i);
				if ((i%20)==0)
					d1.setLoc("Blr");
				else
					d1.setLoc("Pnq");
				dao.insert(d1);
			}
			dao.delete(30);
			Dept d = new Dept();
			d.setDeptno(10);
			d.setDname("TRAINING");
			d.setLoc("Hyderabad");
			dao.update(d);
			dao.list().forEach(System.out::println);
			
	}

}
