package custom;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;


@Controller
@RequestMapping(value="/depts")
public class DeptController {

	private List<Dept> list =new ArrayList();
	
	@GetMapping
	@ResponseBody
	public String list(){
		String str = "<Table bgcolor='cyan' border='1'>";
		str +="<tr><td>Deptno</td><td>Dname</td><td>Loc</td></tr>";
		for (Dept dept : list) {
			str += "<tr><td>"+ dept.getDeptno() + "</td><td>"+ dept.getDname()  +"</td><td>"+ dept.getLoc()+"</td></tr>";
		}
		str+= "</table>";
		System.out.println(str);
		return str;
	}
	
	@GetMapping(value="/bydeptno")
	public String delete(@RequestParam(name="deptno") int deptno){
		System.out.println("delete invoked with " + deptno);
		list.removeIf((d)->d.getDeptno()==deptno);
		return "/index.html";
		}
	@PostMapping(value="update")
	public String update(Dept dept1){
			for (Dept dept : list) {
				if (dept.getDeptno()==dept1.getDeptno()){
						dept.setDname(dept1.getDname());
						dept.setLoc(dept1.getLoc());
				}
			}
			System.out.println(" updating..");
			return "/index.html";
	}

	@PostMapping
	public String insert(Dept d){
		System.out.println("insert ..." + d);
		list.add(d);
		System.out.println(list);
		return "/index.html";
	}
	
}
