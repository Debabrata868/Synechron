package params;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(value="/pm")
public class PathVariableDemo {

	@GetMapping(value="/hello/{nm}")
	public String hello(@PathVariable(name="nm")String name){
		System.out.println("hello, " + name);
		return "<h1>Hello, "+ name + "</h1>";
	}
	
	@GetMapping(value="/hello/{v1}/{v2}")
	public String hello
				(@PathVariable(name="v1")int n1,
						@PathVariable(name="v2")int n2		
				){
		System.out.println("add, " + (n1+n2));
		return "<h1>Sum =  "+ (n1+n2) + "</h1>";
	}
}
