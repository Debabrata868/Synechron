package params;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(value="/rp")
public class RequestParamDemo {

	@GetMapping(value="/hello")
	public String hello(@RequestParam(name="nm")String name){
		System.out.println("RequestParamDemo hello, " + name);
		return "<h1>Hello, "+ name + "</h1>";
	}
}
