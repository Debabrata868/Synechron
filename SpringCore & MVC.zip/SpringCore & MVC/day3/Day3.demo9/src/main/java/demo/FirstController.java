package demo;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping(value="/")
public class FirstController {
	@GetMapping
	public String hello(){
		System.out.println("FirstController - Hello - GET Method");
		return "/index.html";
	}
	@PostMapping
	public String hello1(){
		System.out.println("FirstController - Hello POST Method");
		return "/index.html";
	}
	@PutMapping
	@ResponseBody
	public String hello2(){
		System.out.println("FirstController - Hello PUT Method");
		return "hello2 - putmethod invoked ";
	}
	@DeleteMapping
	@ResponseBody
	public String hello3(){
		System.out.println("FirstController - Hello DELETE Method");
		return "hello2 - deletemethod invoked ";
	}
	
}
