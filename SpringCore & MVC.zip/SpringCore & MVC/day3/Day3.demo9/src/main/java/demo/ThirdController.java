package demo;

import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

//@Controller() + @ResponseBody
@RestController
@RequestMapping(value="/third")
public class ThirdController {
	
	@GetMapping(value="/", produces=MediaType.TEXT_PLAIN_VALUE)
	public String hello1(){
		String str = "ThirdController - text";
		System.out.println(str);
		return  str ;
	}
	@GetMapping(value="/", produces=MediaType.TEXT_HTML_VALUE)
	public String hello2(){
		String str = "ThirdController - HTML";
		System.out.println(str);
		return "<h1>"+ str + "</h1>";
	}
	@GetMapping(value="/", produces=MediaType.APPLICATION_JSON_VALUE)
	public String hello3(){
		String str = "ThirdController - JSON";
		System.out.println(str);
		return "{name: \"John\", age: 31, city: \"New York\"}";
	}
	@GetMapping(value="/", produces=MediaType.APPLICATION_XML_VALUE)
	public String hello4(){
		String str = "<?xml version='1.0' encoding='UTF-8'?><note>  <to>Tove</to>  <from>Jani</from> <heading>Reminder</heading>  <body>Don't forget me this weekend!</body></note>";
		
		System.out.println(str);
		return "<h1>"+ str + "</h1>";
	}
	

		
}
