package demo;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller()
@RequestMapping(value="/second")
public class SecondController {
	
	@GetMapping(value="/")
//	@RequestMapping(method=RequestMethod.GET)
	@ResponseBody
	public String hello(){
		System.out.println("SecondController - Hello - GET Method");
		return  "/ SecondController - Hello - GET Method";
	}

	@GetMapping(value="/s1")
	@ResponseBody
	public String hello1(){
		System.out.println("SecondController - Hello1 - GET Method");
		return  "/s1 SecondController - Hello1 - GET Method";
	}
	@GetMapping(value="/s2")
	@ResponseBody
	public String hello2(){
		System.out.println("SecondController - Hello2 - GET Method");
		return  "/s2 SecondController - Hello2 - GET Method";
	}	
}
